#include "Matrix.h"

Matrix::Matrix()
{
    //ctor
}

class Matrix
{
private:
// A structure to store a matrix
  valarray<int> data;       //valarray that will simulate matrix
  int row, col;


  public :
// Takes an array of data and stores in matrix according
// to rows and columns

void setdata ( valarray<int>d )
 {
     data=d ;
 }

 int getdata()
 {
     return data ;
 }


 void setrow ( int r )
 {
     row = r ;
 }

 int getrow()
 {
     return row ;
 }


 void setcol ( int c )
 {
     col = c ;
 }

 int getcol()
 {
     return col ;
}

Matrix Matrix:: void createMatrix (int row, int col, int num[], matrix& mat) {
  mat.row = row;
  mat.col = col;
  mat.data.resize (row * col);
  for (int i = 0; i < row * col; i++)
    mat.data [i] = num [i];
}






/////////////////////////////////////////////////////////////////////////////////////////////////
/*
// part 1

Matrix Matrix::operator+  (Matrix mat1, Matrix mat2) // Add if same dimensions
{ // add if 2 Matricies are Same Direction


}



Matrix Matrix::operator-  (Matrix mat1, Matrix mat2)
{ // Substract if 2 Matricies are Same Direction
}


Matrix Matrix::operator*  (Matrix mat1, Matrix mat2)
{ // Multipliction if ** Matrix1 Column == Matrix2 Row
}


Matrix Matrix::operator+  (Matrix mat1, int scalar)
{ // Add A Scalar

}


Matrix Matrix::operator-  (matrix mat1, int scalar)
{ // Substract A Scalar
}


Matrix Matrix::operator*  (Matrix mat1, int scalar)
{ // Multiply MAtrix by a Scalar


}


*/
/////////////////////////////////////////////////////////////////////////////////////

// part 2

Matrix Matrix::operator+= (matrix& mat1, matrix mat2) // mat1
{
      for (int i = 0; i < mat1.row * mat1.col; i++)
        mat1.data [i] += mat2.data [i];

    return mat1 ;
}

//changes & return new+
//matrix with the sum


Matrix Matrix::operator-= (matrix& mat1, matrix mat2) // mat1
// changes + return new matrix with difference
{
  for (int i = 0; i < mat1.row * mat1.col; i++)
        mat1.data [i] += mat2.data [i];

    return mat1 ;

}


Matrix Matrix::operator+= (matrix& mat, int scalar)   // change mat & return new matrix
{
      for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] += scalar;

    return mat ;

}
Matrix Matrix::operator-= (matrix& mat, int scalar)  // change mat & return new matrix
{
    for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] -= scalar;

    return mat ;

}
Matrix Matrix::void operator++ (matrix& mat)   	// Add 1 to each element ++mat
{
      for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] ++;

}
Matrix Matrix::void operator-- (matrix& mat)    	// Sub 1 from each element --mat
{
    for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] --;

}

Matrix Matrix::istream& operator>> (istream& in, matrix& mat)
// Input matrix like this (dim 2 x 3) cin >> 2 3 4 6 8 9 12 123
       // and return istream to allow cascading input
{
        int row, col;
    in >> row >> col;
    mat.row = row;
    mat.col = col;
    mat.data.resize (row * col);
    for (int i = 0; i < row * col; i++)
        in >> mat.data [i] ;

}

/*
Matrix Matrix::ostream& operator <<(ostream& os,matrix mat){
    cout << "The matrix is \n";
    for(int i = 0 ; i < mat.row ; i++){
        cout << "\n";
        for(int j = 0 ; j < mat.col ; j++){
            cout << setw (4) << mat.data[i * mat.col + j] << "  ";
        }
    }
    return os;
}

void Matrix::operator = (Matrix n)
{
    int y = n.data.size();
    for(int i=0;i<y;i++)
    {
        this->data[i]=n.data[i];

    }

}


       /////////////////////////////////////////////////////////////////////////////////////

       // part 3

Matrix Matrix::ostream& operator<< (ostream& out, matrix mat)
       	// Print matrix  as follows (2 x 3)
        // 4	 6 	  8
	       // and return ostream to cascade printing
           // 9	12  	123
           {

           }
Matrix Matrix::bool operator== (matrix mat1, matrix mat2)	// True if identical
{

}

Matrix Matrix::bool operator!= (matrix mat1, matrix mat2) 	// True if not same
{

}
Matrix Matrix::bool isSquare   (matrix mat)  // True if square matrix
{

}

Matrix Matrix::bool isSymetric (matrix mat)  // True if square and symmetric
{

}
Matrix Matrix::bool isIdentity (matrix mat)  // True if square and identity
{

}
Matrix Matrix::transpose(matrix mat)    // Return new matrix with the transpose
{

}
//__________________________________________


};

*/